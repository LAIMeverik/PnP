Included files with latest changes:
- smt-navigator/main.py
- smt-navigator/DEPLOY_RPI4.md

Commits:
104071f Refine PyCharm testing section wording
014d9a8 Generalize PyCharm path examples in deploy docs
