import sys
import pandas as pd
import re
import json
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QPushButton, QLabel, QFileDialog,
                             QSpinBox, QGroupBox, QMessageBox, QTableWidget,
                             QTableWidgetItem, QHeaderView, QTabWidget, QComboBox, QProgressBar, QScrollArea)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QShortcut, QKeySequence


class SMTNavigator(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SMT Navigator: Пошаговая Перезаправка (Динамические очереди)")
        self.resize(1300, 900)

        self.all_data = None
        self.feeder_map = {}
        self.tape_sizes = [8, 12, 16, 24, 32, 44]
        self.spins = {}
        self.progress_file = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "smt_progress.json",
        )

        progress_data = self.load_progress()
        self.setup_completed = progress_data.get('setup', {})
        self.instr_completed = progress_data.get('instr', {})
        self.global_feeder_map = progress_data.get('global_feeder_map') or {}
        self.batch_comps = {}

        # Горячие клавиши (Enter)
        self.shortcut_enter = QShortcut(QKeySequence("Return"), self)
        self.shortcut_enter.activated.connect(self.toggle_completed)
        self.shortcut_enter_num = QShortcut(QKeySequence("Enter"), self)
        self.shortcut_enter_num.activated.connect(self.toggle_completed)

        self.setStyleSheet("""
            QMainWindow { background-color: #1a1a1a; }
            QLabel { color: #ffffff; font-size: 13px; }
            QGroupBox { color: #007AFF; font-weight: bold; border: 1px solid #333; margin-top: 10px; }
            QPushButton { border-radius: 6px; padding: 10px; font-weight: bold; }
            QTableWidget { background-color: #222; color: #ddd; gridline-color: #333; }
            QHeaderView::section { background-color: #333; color: white; }
            QComboBox { background-color: #007AFF; color: white; font-weight: bold; padding: 5px; }
        """)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        # ПАНЕЛЬ УПРАВЛЕНИЯ
        top_group = QGroupBox("ПАНЕЛЬ УПРАВЛЕНИЯ И КОНФИГУРАЦИЯ")
        top_layout = QVBoxLayout(top_group)

        file_run_lay = QHBoxLayout()
        self.btn_load = QPushButton("📂 ЗАГРУЗИТЬ ПРОЕКТ")
        self.btn_load.setFixedHeight(35)
        self.btn_load.clicked.connect(self.load_file)

        self.status_label = QLabel("СТАТУС: Ожидание загрузки файла...")
        self.status_label.setStyleSheet("color: #FFC107; font-weight: bold; font-size: 13px;")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.btn_run = QPushButton("⚡ РАССЧИТАТЬ БАЗУ")
        self.btn_run.setFixedHeight(35)
        self.btn_run.setStyleSheet("background-color: #2E7D32; color: white;")
        self.btn_run.clicked.connect(self.calculate_global)

        file_run_lay.addWidget(self.btn_load, stretch=1)
        file_run_lay.addWidget(self.status_label, stretch=3)
        file_run_lay.addWidget(self.btn_run, stretch=1)
        top_layout.addLayout(file_run_lay)

        # Конфигурация фидеров (ленты)
        cfg_lay = QHBoxLayout()
        cfg_lay.addWidget(QLabel("<b>Доступные слоты:</b>"))
        for s in self.tape_sizes:
            sp = QSpinBox()
            sp.setRange(0, 500)
            # В павуке нет 8мм, поэтому по умолчанию ставим 0
            sp.setValue(0 if s == 8 else 10)
            sp.setFixedWidth(60)
            sp.setFixedHeight(30)
            lbl = QLabel(f"{s}мм:")
            lbl.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            cfg_lay.addWidget(lbl)
            cfg_lay.addWidget(sp)
            self.spins[s] = sp
        tape_limits = progress_data.get('tape_limits', {})
        for s in self.tape_sizes:
            key = str(s)
            if key in tape_limits:
                try:
                    self.spins[s].setValue(int(tape_limits[key]))
                except (TypeError, ValueError):
                    pass
        cfg_lay.addStretch()
        top_layout.addLayout(cfg_lay)

        # Выбор платы
        bs_layout = QHBoxLayout()
        bs_layout.addWidget(QLabel("<b>ТEКУЩАЯ СБОРКА:</b>"))
        self.board_sel = QComboBox()
        self.board_sel.setFixedHeight(30)
        self.board_sel.currentIndexChanged.connect(self.render_board_data)
        bs_layout.addWidget(self.board_sel, stretch=1)
        self.recharge_warning = QLabel("")
        self.recharge_warning.setWordWrap(True)
        bs_layout.addWidget(self.recharge_warning, stretch=2)
        top_layout.addLayout(bs_layout)

        layout.addWidget(top_group)

        # ПАНЕЛЬ ПРОГРЕССА
        self.progress_box = QGroupBox("ПРОГРЕСС УСТАНОВКИ")
        self.progress_box.setMaximumHeight(140)
        self.progress_layout = QVBoxLayout()
        scroll_prog = QScrollArea()
        scroll_prog.setWidgetResizable(True)
        self.prog_container = QWidget()
        self.prog_container.setLayout(self.progress_layout)
        scroll_prog.setWidget(self.prog_container)
        box_lay = QVBoxLayout()
        box_lay.addWidget(scroll_prog)
        self.progress_box.setLayout(box_lay)
        layout.addWidget(self.progress_box)

        # СВОДКА ПРОЕКТА
        self.summary_box = QGroupBox("ОБЩАЯ ИНФОРМАЦИЯ ПО ПЛАТЕ")
        slayout = QHBoxLayout()
        self.lbl_total_parts = QLabel("Всего компонентов: 0")
        self.lbl_unique_parts = QLabel("Уникальных: 0")
        self.lbl_feeders_used = QLabel("Занято фидеров: 0")
        self.lbl_next_board = QLabel("Рекомендуемая следующая: -")
        for lbl in (self.lbl_total_parts, self.lbl_unique_parts, self.lbl_feeders_used, self.lbl_next_board):
            lbl.setStyleSheet(
                "font-size: 14px; color: #E0E0E0; background-color: #333; padding: 5px; border-radius: 5px;")
            slayout.addWidget(lbl)
        self.summary_box.setLayout(slayout)
        layout.addWidget(self.summary_box)

        # ТАБЛИЦЫ И ВКЛАДКИ
        self.tabs = QTabWidget()

        self.tab_visual = QWidget()
        self.tabs.addTab(self.tab_visual, " ВИЗУАЛЬНАЯ КАРТА СТАНКОВ")
        self.setup_visual_tab()

        self.tab_compat = QWidget()
        self.tabs.addTab(self.tab_compat, "🔗 СОВМЕСТИМОСТЬ ПЛАТ (ЧТО СОБИРАТЬ ДАЛЬШЕ)")
        self.setup_compat_tab()

        self.table_setup = QTableWidget()
        self.table_setup.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.tabs.addTab(self.table_setup, "🛠 КАРТА ЗАПРАВКИ (Что поставить в станок)")

        self.table_instr = QTableWidget()
        self.table_instr.itemDoubleClicked.connect(self._on_item_double_clicked)
        self.tabs.addTab(self.table_instr, "📋 СПИСОК УСТАНОВКИ (Куда ставить на плате)")

        layout.addWidget(self.tabs)

    def closeEvent(self, event):
        self.save_progress()
        super().closeEvent(event)

    def setup_visual_tab(self):
        v_layout = QVBoxLayout(self.tab_visual)
        ctrl_layout = QHBoxLayout()
        ctrl_layout.addWidget(QLabel("<b>Отображаемый станок:</b>"))
        self.visual_batch_sel = QComboBox()
        self.visual_batch_sel.setFixedHeight(30)
        self.visual_batch_sel.addItems(["ЧИПШУТЕР", "ПАВУК"])
        self.visual_batch_sel.currentIndexChanged.connect(self.render_visual_map)
        ctrl_layout.addWidget(self.visual_batch_sel)
        ctrl_layout.addStretch()
        v_layout.addLayout(ctrl_layout)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.visual_container = QWidget()
        self.visual_layout = QVBoxLayout(self.visual_container)
        scroll.setWidget(self.visual_container)
        v_layout.addWidget(scroll)
        self.visual_slot_widgets = {}

    def setup_compat_tab(self):
        c_layout = QVBoxLayout(self.tab_compat)
        lbl = QLabel(
            "Анализ пересечений с другими платами (помогает выбрать, какую плату выгоднее собирать следующей):")
        lbl.setStyleSheet("font-size: 14px; font-weight: bold; color: #E0E0E0; margin-bottom: 5px;")
        c_layout.addWidget(lbl)
        self.table_compat = QTableWidget()
        c_layout.addWidget(self.table_compat)

    def load_file(self):
        fn, _ = QFileDialog.getOpenFileName(self, "BOM", "", "Excel (*.xlsx *.xls)")
        if fn:
            self.status_label.setText("СТАТУС: Файл загружен. Готов к расчету.")
            self.status_label.setStyleSheet("color: #4CAF50; font-weight: bold; font-size: 14px;")
            xls = pd.ExcelFile(fn)
            self.all_data = pd.concat([pd.read_excel(xls, s).assign(Sheet=s) for s in xls.sheet_names])
            self.all_data.columns = self.all_data.columns.str.strip()
            self.board_sel.clear()
            self.board_sel.addItems(xls.sheet_names)

    def calculate_global(self):
        if self.all_data is None: return

        self.global_parts = self.all_data.groupby('Name').agg({'Quantity': 'sum'}).reset_index()
        self.status_label.setText("СТАТУС: Базовые данные подготовлены. Выберите плату для работы.")
        QMessageBox.information(self, "Готово", "Данные загружены. Выберите плату для расчета.")

        # Если feeder_map пуст, мы должны инициализировать слоты
        # (или позволить render_board_data сделать это с сохранением)
        self.global_feeder_map = getattr(self, 'global_feeder_map', {})

        self.render_board_data()

    def render_board_data(self):
        board = self.board_sel.currentText()
        if not board: return

        current_board_data = self.all_data[self.all_data['Sheet'] == board]
        unique_parts_current = set(current_board_data['Name'].unique())

        df_board = current_board_data.groupby('Name').agg({
            'Quantity': 'sum',
            'Designator': lambda x: ", ".join(
                sorted(set(str(item) for sublist in x for item in str(sublist).split(',') if str(item).strip()))),
        }).reset_index()

        def parse_w(x):
            m = re.search(r'(\d+)', str(x))
            w = int(m.group(1)) if m else 8
            return next((s for s in self.tape_sizes if w <= s), 44)

        # Вытягиваем глобальную информацию о ширине ленты для всех компонентов проекта
        all_comps_info = self.all_data.groupby('Name').agg({'Тип ленты': 'first'}).reset_index()
        all_comps_info['mm'] = all_comps_info['Тип ленты'].apply(parse_w)

        # Используем глобальный feeder_map для сохранения позиций
        if not hasattr(self, 'global_feeder_map'):
            self.global_feeder_map = {}
        self.feeder_map = self.global_feeder_map.copy()

        # Получаем список того, что УЖЕ установлено в станки на данный момент
        global_setup = set()
        for comps in self.setup_completed.values():
            global_setup.update(comps)

        # Удаляем из feeder_map то, что НЕ установлено (если мы хотим, чтобы они могли занять новые места потом)
        # но мы хотим сохранить их или нет? Оставляем как есть, чтобы не сдвигать
        keys_to_remove = []
        for name in list(self.feeder_map.keys()):
            if name not in global_setup and name not in unique_parts_current:
                 # Если компонент не в глобальной установке и не на текущей плате, можно убрать его место
                 # Или можно оставить, если мы хотим, чтобы места вообще не переиспользовались?
                 # Уберем, чтобы освободить место
                 keys_to_remove.append(name)
        for k in keys_to_remove:
            del self.feeder_map[k]

        # 1. Сначала резервируем места для УЖЕ установленных компонентов (даже если они не нужны для текущей платы)
        # Они уже должны быть в feeder_map!
        installed_info = all_comps_info[all_comps_info['Name'].isin(global_setup)]

        # 2. Потом готовим список новых компонентов, которые нужны ТОЛЬКО для текущей платы
        new_info = all_comps_info[
            (all_comps_info['Name'].isin(unique_parts_current)) & (~all_comps_info['Name'].isin(global_setup))]

        # --- ЧИПШУТЕР (Только 8мм) ---
        cs_new = new_info[new_info['mm'] == 8]

        # Находим максимальный слот, который уже занят, чтобы продолжить с него
        used_cs_slots = set()
        for name, info in self.feeder_map.items():
            if info['station'] == 'ЧИПШУТЕР':
                used_cs_slots.add(info['slot'])

        b_id, slot_idx, side = 1, 5, 'L'

        # Функция для поиска первого свободного слота чипшутера
        def get_next_cs_slot():
            nonlocal b_id, slot_idx, side
            while f"{side}{slot_idx}" in used_cs_slots:
                slot_idx += 1
                if slot_idx > 29:
                    slot_idx = 5
                    side = 'R' if side == 'L' else 'L'
                    if side == 'L': b_id += 1
            slot = f"{side}{slot_idx}"
            used_cs_slots.add(slot)
            return b_id, slot

        # Для новых назначаем новые слоты
        for _, r in cs_new.iterrows():
            cur_b_id, cur_slot = get_next_cs_slot()
            self.feeder_map[r['Name']] = {'batch': cur_b_id, 'slot': cur_slot, 'station': 'ЧИПШУТЕР'}
            self.global_feeder_map[r['Name']] = self.feeder_map[r['Name']]

        # --- ПАВУК (Все что больше 8мм) ---
        pv_new = new_info[new_info['mm'] > 8]

        limits = {s: self.spins[s].value() for s in self.tape_sizes}
        usage = {s: 0 for s in self.tape_sizes}
        sp_b_id, l_idx, r_idx = 1, 1, 1

        # Восстанавливаем usage и индексы для павука из уже назначенных
        used_pv_slots = set()
        for name, info in self.feeder_map.items():
            if info['station'] == 'ПАВУК':
                used_pv_slots.add(info['slot'].split(' ')[0]) # L1-L2 и т.д.
                w_str = re.search(r'\((\d+)мм\)', info['slot'])
                if w_str:
                    w = int(w_str.group(1))
                    usage[w] = usage.get(w, 0) + 1

        # ... logic for continuing pv ... (simplified for now to just append)
        # We need a robust way to find next slots for spider
        def assign_pv(w, name):
            nonlocal sp_b_id, l_idx, r_idx, usage
            slots_needed = 3 if w in (32, 44) else 2

            if limits.get(w, 0) > 0 and usage[w] >= limits.get(w, 0):
                sp_b_id += 1
                usage = {s: 0 for s in self.tape_sizes}
                l_idx, r_idx = 1, 1

            assigned_slot = None

            while True:
                if l_idx + slots_needed - 1 <= 20:
                    cand = f"L{l_idx}-L{l_idx + slots_needed - 1}"
                    if cand not in used_pv_slots:
                        assigned_slot = cand
                        l_idx += slots_needed
                        break
                    l_idx += 1
                elif r_idx + slots_needed - 1 <= 20:
                    cand = f"R{r_idx}-R{r_idx + slots_needed - 1}"
                    if cand not in used_pv_slots:
                        assigned_slot = cand
                        r_idx += slots_needed
                        break
                    r_idx += 1
                else:
                    sp_b_id += 1
                    usage = {s: 0 for s in self.tape_sizes}
                    l_idx = 1
                    r_idx = 1

            if assigned_slot:
                usage[w] += 1
                used_pv_slots.add(assigned_slot)
                self.feeder_map[name] = {'batch': sp_b_id, 'slot': f'{assigned_slot} ({w}мм)', 'station': 'ПАВУК'}
                self.global_feeder_map[name] = self.feeder_map[name]

        for _, r in pv_new.iterrows(): assign_pv(r['mm'], r['Name'])

        # === АНАЛИЗ СОВМЕСТИМОСТИ ПЛАТ ===
        other_boards_matches = []
        for other_board in self.all_data['Sheet'].unique():
            if other_board == board: continue
            other_data = self.all_data[self.all_data['Sheet'] == other_board]
            unique_other = set(other_data['Name'].unique())
            shared = unique_parts_current.intersection(unique_other)
            new_comps = unique_other - unique_parts_current
            shared_str = sorted([str(x) for x in shared])
            new_comps_str = sorted([str(x) for x in new_comps])

            other_boards_matches.append({
                'ПЛАТА': other_board,
                'ОБЩИХ КОМП.': len(shared),
                'НОВЫХ КОМП.': len(new_comps),
                'КАКИЕ УЖЕ В СТАНКЕ': ", ".join(shared_str),
                'ЧТО ПРИДЕТСЯ ДОБАВИТЬ': ", ".join(new_comps_str),
                'shared_comps': shared
            })

        other_boards_matches.sort(key=lambda x: x['ОБЩИХ КОМП.'], reverse=True)
        self.shared_with_next = set()
        if other_boards_matches and other_boards_matches[0]['ОБЩИХ КОМП.'] > 0:
            best_match = other_boards_matches[0]
            self.lbl_next_board.setText(
                f" РЕКОМЕНДУЕМ ПОСЛЕ ЭТОЙ СОБИРАТЬ: {best_match['ПЛАТА']} (Общих: {best_match['ОБЩИХ КОМП.']})")
            self.lbl_next_board.setStyleSheet(
                "font-size: 16px; color: #FFFFFF; background-color: #D84315; padding: 8px; border-radius: 5px; font-weight: bold;")
            self.shared_with_next = best_match['shared_comps']
        else:
            self.lbl_next_board.setText("Рекомендаций для след. платы: нет")
            self.lbl_next_board.setStyleSheet(
                "font-size: 14px; color: #E0E0E0; background-color: #333; padding: 5px; border-radius: 5px;")

        df_compat = pd.DataFrame([{k: v for k, v in m.items() if k != 'shared_comps'} for m in other_boards_matches])
        if not df_compat.empty:
            self.fill_t(self.table_compat, df_compat)
            self.table_compat.setWordWrap(True)
            self.table_compat.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)

        # === ФОРМИРОВАНИЕ ТАБЛИЦ ДЛЯ ВЫБРАННОЙ ПЛАТЫ ===
        total_qty = df_board['Quantity'].sum()
        unique_parts = len(df_board)
        self.lbl_total_parts.setText(f"Всего компонентов: {total_qty}")
        self.lbl_unique_parts.setText(f"Уникальных: {unique_parts}")

        setup_rows = []
        instr_rows = []
        self.batch_comps = {}

        # Формируем таблицы только для тех компонентов, которые есть на текущей плате
        for _, r in df_board.iterrows():
            info = self.feeder_map.get(r['Name'], {'batch': '?', 'slot': '?', 'station': '?'})
            b_name = f"{info['station']} №{info['batch']}"

            if b_name not in self.batch_comps:
                self.batch_comps[b_name] = []
            self.batch_comps[b_name].append(r['Name'])

            setup_rows.append({
                'СТАНОК': info['station'],
                'ОЧЕРЕДЬ (ЗАГРУЗКА)': f"№ {info['batch']}",
                'ПОЗИЦИЯ / ФИДЕР': info['slot'],
                'ЧТО СТАВИМ': r['Name'],
                'НУЖНО ШТ': r['Quantity']
            })

            instr_rows.append({
                'ПРИОРИТЕТ': f"{info['station']} (Батч {info['batch']})",
                'ДЕТАЛЬ': r['Name'],
                'СЛОТ': info['slot'],
                'КОЛ-ВО': r['Quantity'],
                'ПОЗИЦИИ (DESIGNATORS)': r['Designator']
            })

        self.lbl_feeders_used.setText(f"Задействовано слотов: {unique_parts}")

        cs_batches = [b for b in self.batch_comps.keys() if "ЧИПШУТЕР" in b]
        pv_batches = [b for b in self.batch_comps.keys() if "ПАВУК" in b]

        warn_text = []
        if len(cs_batches) > 1: warn_text.append(f"Чипшутер - {len(cs_batches)} захода")
        if len(pv_batches) > 1: warn_text.append(f"Павук - {len(pv_batches)} захода")

        if warn_text:
            self.recharge_warning.setText(f"⚠️ ТРЕБУЕТСЯ ПЕРЕЗАПРАВКА! ({', '.join(warn_text)})")
            self.recharge_warning.setStyleSheet("color: #FF5252; font-weight: bold; font-size: 14px;")
        else:
            self.recharge_warning.setText("✅ Влазит в один заход (без перезаправок)")
            self.recharge_warning.setStyleSheet("color: #4CAF50; font-weight: bold; font-size: 14px;")

        df_setup = pd.DataFrame(setup_rows).sort_values(by=['СТАНОК', 'ОЧЕРЕДЬ (ЗАГРУЗКА)'])
        df_instr = pd.DataFrame(instr_rows).sort_values(by='ПРИОРИТЕТ')

        self.fill_t(self.table_setup, df_setup)
        self.fill_t(self.table_instr, df_instr)
        self.render_progress_panel(board)
        self.render_visual_map()
        self.refresh_ui_status()

    def render_visual_map(self):
        def clear_layout(layout):
            if layout is not None:
                while layout.count():
                    item = layout.takeAt(0)
                    widget = item.widget()
                    if widget is not None:
                        widget.deleteLater()
                    else:
                        clear_layout(item.layout())

        clear_layout(self.visual_layout)
        self.visual_slot_widgets.clear()

        station_filter = self.visual_batch_sel.currentText()
        if not station_filter: return

        is_chipshooter = "ЧИПШУТЕР" in station_filter

        main_split = QHBoxLayout()
        self.visual_layout.addLayout(main_split)

        machine_group = QGroupBox(f"ГРАФИКА СТАНКА (ТОЛЬКО УСТАНОВЛЕННЫЕ ДЕТАЛИ): {station_filter}")
        m_lay = QHBoxLayout(machine_group)

        self.visual_warning_lbl = QLabel("")
        self.visual_warning_lbl.setStyleSheet("color: #FF5252; font-weight: bold; font-size: 14px;")
        self.visual_warning_lbl.setWordWrap(True)
        self.visual_layout.insertWidget(0, self.visual_warning_lbl)

        l_slots_lay = QVBoxLayout()
        r_slots_lay = QVBoxLayout()

        center_board = QLabel("РАБОЧАЯ ЗОНА СТАНКА\n(Кликните на деталь сбоку,\nчтобы снять её со станка)")
        center_board.setAlignment(Qt.AlignmentFlag.AlignCenter)
        center_board.setStyleSheet(
            "background-color: #444; border: 2px dashed #777; border-radius: 10px; font-weight: bold; font-size: 14px; color: #FFF;")

        m_lay.addLayout(l_slots_lay)
        m_lay.addWidget(center_board, stretch=2)
        m_lay.addLayout(r_slots_lay)

        main_split.addWidget(machine_group, stretch=3)

        side_group = QGroupBox("ФИЗИЧЕСКИ НАХОДИТСЯ В СТАНКЕ")
        s_lay = QVBoxLayout(side_group)
        side_table = QTableWidget()
        side_table.setColumnCount(2)
        side_table.setHorizontalHeaderLabels(["СЛОТ", "КОМПОНЕНТ"])
        side_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        side_table.setStyleSheet("background-color: #222; color: white;")
        s_lay.addWidget(side_table)
        main_split.addWidget(side_group, stretch=2)

        # Выводим ТОЛЬКО те компоненты, которые были отмечены как установленные
        global_setup = set()
        for comps in self.setup_completed.values():
            global_setup.update(comps)

        components = []
        for name in global_setup:
            info = self.feeder_map.get(name)
            if info and info['station'] == station_filter:
                components.append((name, info['slot']))

        limit = 50 if is_chipshooter else sum(sp.value() for sp in self.spins.values())
        if len(components) > limit:
            self.visual_warning_lbl.setText(
                f"⚠️ ВНИМАНИЕ: Установлено деталей ({len(components)} шт.) больше, чем доступно слотов ({limit} шт.)! Снимите лишние.")
        else:
            self.visual_warning_lbl.setText("")

        components.sort(key=lambda x: str(x[1]))
        side_table.setRowCount(len(components))
        for i, (comp, slot) in enumerate(components):
            side_table.setItem(i, 0, QTableWidgetItem(slot))
            side_table.setItem(i, 1, QTableWidgetItem(comp))

        class ClickableLabel(QLabel):
            def __init__(self, text, comp_name, parent_ref):
                super().__init__(text)
                self.comp_name = comp_name
                self.parent_ref = parent_ref

            def mousePressEvent(self, event):
                if event.button() == Qt.MouseButton.LeftButton and self.comp_name:
                    removed = False
                    for b_name, d_list in self.parent_ref.setup_completed.items():
                        if self.comp_name in d_list:
                            d_list.remove(self.comp_name)
                            removed = True
                    if removed:
                        self.parent_ref.save_progress()
                        self.parent_ref.render_board_data()  # Перерасчет очередей при снятии детали
                        self.parent_ref.refresh_ui_status()

        def create_slot_widget(slot_id, comp_name):
            w = QWidget()
            w.setStyleSheet("background-color: #333; border: 1px solid #555; margin: 1px;")
            w.setMinimumHeight(24)
            l = QHBoxLayout(w)
            l.setContentsMargins(2, 2, 2, 2)
            lbl_s = QLabel(slot_id)
            lbl_s.setStyleSheet(
                "color: #AAA; font-weight: bold; font-size: 11px; border: none; background: transparent;")
            lbl_s.setFixedWidth(40)

            lbl_c = ClickableLabel(comp_name if comp_name else "—", comp_name, self)
            lbl_c.setStyleSheet(
                "color: white; font-size: 11px; border: none; background: transparent; cursor: pointer;")
            lbl_c.setWordWrap(True)
            if comp_name: lbl_c.setToolTip("Кликните, чтобы снять деталь со станка")

            l.addWidget(lbl_s)
            l.addWidget(lbl_c)

            if comp_name: self.visual_slot_widgets[comp_name] = w
            return w

        if is_chipshooter:
            for i in range(5, 30):
                slot_l = f"L{i}"
                comp_l_list = [c[0] for c in components if c[1] == slot_l]
                l_slots_lay.addWidget(create_slot_widget(slot_l, comp_l_list[0] if comp_l_list else ""))

                slot_r = f"R{i}"
                comp_r_list = [c[0] for c in components if c[1] == slot_r]
                r_slots_lay.addWidget(create_slot_widget(slot_r, comp_r_list[0] if comp_r_list else ""))
        else:
            l_comps = [(c, s) for c, s in components if str(s).startswith('L')]
            r_comps = [(c, s) for c, s in components if str(s).startswith('R')]

            for c, s in l_comps: l_slots_lay.addWidget(create_slot_widget(s, c))
            for c, s in r_comps: r_slots_lay.addWidget(create_slot_widget(s, c))
            l_slots_lay.addStretch()
            r_slots_lay.addStretch()

        self.refresh_ui_status()

    def _on_item_double_clicked(self, item):
        self.toggle_completed()

    def render_progress_panel(self, board):
        for i in reversed(range(self.progress_layout.count())):
            w = self.progress_layout.itemAt(i).widget()
            if w: w.deleteLater()

        if board not in self.instr_completed: self.instr_completed[board] = []

        sorted_batches = sorted(self.batch_comps.keys())
        for b in sorted_batches:
            comps_in_batch = self.batch_comps[b]
            total = len(comps_in_batch)
            completed = sum(1 for c in comps_in_batch if c in self.instr_completed[board])

            lbl = QLabel(f"{b}: {completed} / {total}")
            lbl.setStyleSheet("font-weight: bold; font-size: 12px; color: #FFF; min-width: 100px;")

            pb = QProgressBar()
            pb.setFixedHeight(12)
            pb.setMaximum(total)
            pb.setValue(completed)
            pb.setStyleSheet(
                "QProgressBar { border: 1px solid #555; border-radius: 5px; text-align: center; color: white; background-color: #222; } QProgressBar::chunk { background-color: #4CAF50; }")

            row_widget = QWidget()
            hlay = QHBoxLayout(row_widget)
            hlay.setContentsMargins(0, 0, 0, 5)
            hlay.addWidget(lbl)
            hlay.addWidget(pb)
            self.progress_layout.addWidget(row_widget)

    def toggle_completed(self):
        board = self.board_sel.currentText()
        if not board: return

        fw = QApplication.focusWidget()
        if fw == self.table_setup:
            table, name_col, target_dict = self.table_setup, 3, self.setup_completed
        elif fw == self.table_instr:
            table, name_col, target_dict = self.table_instr, 1, self.instr_completed
        else:
            return

        selected_rows = list(set(item.row() for item in table.selectedItems()))
        if not selected_rows: return

        comps_to_toggle = [table.item(r, name_col).text() for r in selected_rows if table.item(r, name_col).text()]

        if board not in target_dict: target_dict[board] = []

        all_done = all(c in target_dict[board] for c in comps_to_toggle)
        for c in comps_to_toggle:
            if all_done:
                if c in target_dict[board]: target_dict[board].remove(c)
            else:
                if c not in target_dict[board]: target_dict[board].append(c)

        self.save_progress()

        # Если изменили статус установки в станок, нужен полный перерасчет очередей
        if fw == self.table_setup:
            self.render_board_data()
        else:
            self.render_progress_panel(board)
            self.refresh_ui_status()

    def refresh_ui_status(self):
        board = self.board_sel.currentText()
        setup_done = self.setup_completed.get(board, [])
        instr_done = self.instr_completed.get(board, [])

        self._color_table(self.table_setup, 3, setup_done, True)
        self._color_table(self.table_instr, 1, instr_done, False)

        shared_list = getattr(self, 'shared_with_next', set())
        global_setup = set()
        for comps in self.setup_completed.values(): global_setup.update(comps)

        if hasattr(self, 'visual_slot_widgets'):
            for comp, widget in self.visual_slot_widgets.items():
                if comp in global_setup:
                    if comp in shared_list:
                        widget.setStyleSheet("background-color: #D84315; border: 2px solid #FF7043; margin: 1px;")
                    else:
                        widget.setStyleSheet("background-color: #1b5e20; border: 2px solid #4CAF50; margin: 1px;")
                else:
                    widget.setStyleSheet("background-color: #333; border: 1px solid #555; margin: 1px;")

    def _color_table(self, table, name_col, done_list, is_setup_table):
        shared_list = getattr(self, 'shared_with_next', set())
        for r in range(table.rowCount()):
            comp = table.item(r, name_col).text()
            is_done = comp in done_list
            is_shared = comp in shared_list and is_setup_table

            bg = QColor("#1b5e20") if is_done else QColor("#D84315") if is_shared else QColor("#222")

            for c in range(table.columnCount()):
                item = table.item(r, c)
                if not is_done and not is_shared:
                    val = item.text()
                    item.setBackground(QColor("#424242") if "№" in val and "1" not in val else bg)
                else:
                    item.setBackground(bg)

    def load_progress(self):
        if os.path.exists(self.progress_file):
            try:
                with open(self.progress_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if 'setup' not in data:
                        return {'setup': data, 'instr': {}}
                    return data
            except Exception:
                pass
        return {'setup': {}, 'instr': {}}

    def save_progress(self):
        tape_limits = {str(s): self.spins[s].value() for s in self.tape_sizes}
        feeder_map = getattr(self, 'global_feeder_map', None)
        if feeder_map is None:
            feeder_map = {}
        payload = {
            'setup': self.setup_completed,
            'instr': self.instr_completed,
            'global_feeder_map': feeder_map,
            'tape_limits': tape_limits,
        }
        try:
            with open(self.progress_file, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print("Ошибка сохранения:", e)

    def fill_t(self, table, df):
        table.setRowCount(0)
        table.setColumnCount(len(df.columns))
        table.setHorizontalHeaderLabels(df.columns)
        table.setRowCount(len(df))
        for i in range(len(df)):
            for j in range(len(df.columns)):
                val = str(df.iloc[i, j])
                item = QTableWidgetItem(val)
                if "ЧИПШУТЕР" in val: item.setForeground(QColor("#81C784"))
                if "ПАВУК" in val: item.setForeground(QColor("#64B5F6"))
                table.setItem(i, j, item)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    w = SMTNavigator()
    w.show()
    sys.exit(app.exec())